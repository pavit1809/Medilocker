# SE-WINSEM-21-22-Proj
Web Application allowing users to upload documents and assign ACL's to them to control who can view them with a amazing UX.

# Tech Stack
## Backend
1. Nodejs Runtime.
1. Expressjs for API development.
1. MongoDB for database.
1. Heroku for Hosting(aspirational)

## Frontend
1. Reactjs

