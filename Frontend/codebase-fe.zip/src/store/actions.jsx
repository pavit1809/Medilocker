export const CHANGE_USER = 'CHANGE_USER';
export const CHANGE_RECORD = 'CHANGE_RECORD';
